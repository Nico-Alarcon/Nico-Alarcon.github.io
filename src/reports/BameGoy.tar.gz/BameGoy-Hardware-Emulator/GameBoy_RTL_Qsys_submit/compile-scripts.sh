#!/usr/bin/bash

make qsys-clean && make qsys && make rbf;
embedded_command_shell.sh;
make dtb;
